//слайд фото в товаре
function product_image_slider() {
  if ($('.product_page__images_mini').length){
    var galleryThumbs = new Swiper('.product_page__images_mini .swiper-container', {
        loop: false,
        slidesPerView: 6,
        spaceBetween: 10,
        freeMode: false,
		lazy: false,
        watchSlidesVisibility: true
    });
    var gallery = new Swiper('.product_page__images .swiper-container', {
        loop: false,
		lazy: false,
        slidesPerView: 1,
        spaceBetween: 0,
        thumbs: {
          swiper: galleryThumbs,
        }
    });
  }
}
//слайд фото в АКД
function akd_image_slider() {
  if ($('.akd-1-images .product_page__images_mini').length){
    var galleryThumbs = new Swiper('.product_page__images_mini .swiper-container', {
        loop: true,
        slidesPerView: 6,
        spaceBetween: 10,
        freeMode: false,
        watchSlidesVisibility: true,
        /*autoplay: {
            delay: 2000,
        },*/
    });
    var gallery = new Swiper('.akd-1-images .product_page__images .swiper-container', {
        loop: true,
        slidesPerView: 1,
        spaceBetween: 0,
        thumbs: {
          swiper: galleryThumbs,
        },
        autoplay: {
            delay: 2000,
        },
    });
  }
}
//слайд фото в проекте
function project_image_slider() {
  if ($('.project_page__images').length){
    var gallery = new Swiper('.project_page__images .swiper-container', {
        loop: false,
        slidesPerView: 1,
        spaceBetween: 0,
        effect: 'fade',
        pagination: {
            el: '.project-images .project-item-pagination',
            clickable: true,
        },
        autoplay: {
            delay: 4000,
        },
    });
  }
}
//слайд фото в списке проектов
function project_list_slider($project_id) {
  //if ($('.project-item').length){
    var gallery = new Swiper('.project-item[data-project_id = "'+$project_id+'"] .swiper-container', {
        loop: false,
        slidesPerView: 1,
        spaceBetween: 0,
        effect: 'fade',
        pagination: {
            el: '.project-item[data-project_id = "'+$project_id+'"] .project-item-pagination',
            clickable: true,
        },
    });
  //}
}
//слайд фото в блоках проекта
function project_block_slider($block_id) {
  //if ($('.project-item').length){
    var gallery = new Swiper('.gallery-type-container[data-gallery = "'+$block_id+'"] .swiper-container', {
        loop: false,
        slidesPerView: 1,
        spaceBetween: 0,
        effect: 'slide',
        navigation: {
            nextEl: '.gallery-type-container[data-gallery = "'+$block_id+'"] .slide-button-next',
            prevEl: '.gallery-type-container[data-gallery = "'+$block_id+'"] .slide-button-prev',
        },
    });
  //}
}
function akd_compare_slider() {
  if ($('.akd-compare').length){
    var gallery = new Swiper('.akd-compare .swiper-container', {
        loop: true,
        slidesPerView: 1,
        spaceBetween: 0,
        effect: 'slide',
        navigation: {
            nextEl: '.akd-compare .slide-button-next',
            prevEl: '.akd-compare .slide-button-prev',
        },
        autoplay: {
            delay: 4000,
        },
    });
  }
}

function franchise_slider() {
  if ($('.franchise-slider').length){
    var gallery = new Swiper('.franchise-slider .swiper-container', {
        loop: false,
        slidesPerView: 2,
        spaceBetween: 0,
        effect: 'slide',
        navigation: {
            nextEl: '.franchise-slider .slide-button-next',
            prevEl: '.franchise-slider .slide-button-prev',
        },
    });
  }
}
function home_project_slider() {
  if ($('.home-project-slider').length){
    var gallery = new Swiper('.home-project-slider .swiper-container', {
        loop: false,
        slidesPerView: 2,
        spaceBetween: 0,
        effect: 'slide',
        navigation: {
            nextEl: '.home-project-slider .slide-button-next, .home-project-slider .slide-button-next-invis',
            prevEl: '.home-project-slider .slide-button-prev, .home-project-slider .slide-button-prev-invis',
          },
    });
  }
}
function home_reviews_slider() {
  if ($('.home-reviews-slider').length){
    var gallery = new Swiper('.home-reviews-slider .swiper-container', {
        loop: false,
        slidesPerView: 1,
        spaceBetween: 100,
        effect: 'slide',
        navigation: {
            nextEl: '.home-reviews-slider .slide-button-next, .home-reviews-slider .slide-button-next-invis',
            prevEl: '.home-reviews-slider .slide-button-prev, .home-reviews-slider .slide-button-prev-invis',
          },
    });
  }
}
function team_slider() {
  if ($('.team-slider').length){
    var gallery = new Swiper('.team-slider .swiper-container', {
        loop: false,
        slidesPerView: 3,
        spaceBetween: 0,
        effect: 'slide',
        navigation: {
            nextEl: '.team-slider .slide-button-next',
            prevEl: '.team-slider .slide-button-prev',
        },
        pagination: {
            el: '.team-slider .standard-pagination',
            clickable: true,
        },
    });
  }
}
function factory_slider_1() {
  if ($('.factory-slide-1').length){
    var gallery = new Swiper('.factory-slide-1 .swiper-container', {
        loop: false,
        slidesPerView: 2,
        spaceBetween: 30,
        //slidesPerGroup: 2,
        effect: 'slide',
        pagination: {
            el: '.factory-slide-1 .standard-pagination',
            clickable: true,
        },
    });
  }
}
function factory_slider_2() {
  if ($('.factory-slide-2').length){
    var gallery = new Swiper('.factory-slide-2 .swiper-container', {
        loop: false,
        slidesPerView: 2,
        spaceBetween: 30,
        //slidesPerGroup: 2,
        effect: 'slide',
        pagination: {
            el: '.factory-slide-2 .standard-pagination',
            clickable: true,
        },
    });
  }
}
function documents_slider() {
  if ($('.documents-slide').length){
    var gallery = new Swiper('.documents-slide .swiper-container', {
        loop: false,
        slidesPerView: 3,
        spaceBetween: 20,
        //slidesPerGroup: 2,
        effect: 'slide',
        pagination: {
            el: '.documents-slide .standard-pagination',
            clickable: true,
        },
    });
  }
}
function proektirovki_slider() {
  if ($('.proektirovki-slide').length){
    var gallery = new Swiper('.proektirovki-slide .swiper-container', {
        loop: false,
        slidesPerView: 2,
        slidesPerColumn: 2,
        spaceBetween: 30,
        slidesPerGroup: 2,
        effect: 'slide',
        pagination: {
            el: '.proektirovki-slide .standard-pagination',
            clickable: true,
        },
    });
  }
}
function youtube_slider() {
  if ($('.youtube-slider').length){
    var gallery = new Swiper('.youtube-slider .swiper-container', {
        loop: false,
        slidesPerView: 3,
        spaceBetween: 0,
        effect: 'slide',
        slidesPerGroup: 3,
        navigation: {
            nextEl: '.youtube-slider .slide-button-next',
            prevEl: '.youtube-slider .slide-button-prev',
        },
        pagination: {
            el: '.youtube-slider .standard-pagination',
            clickable: true,
        },
    });
  }
}
$.fn.notExists = function() { //Проверка на существование элемента
    return $(this).length==0;
};

if ($('.home-screen-1').length){
    var gallery = new Swiper('.home-screen-1 .swiper-container', {
        loop: true,
        slidesPerView: 1,
        spaceBetween: 0,
        effect: 'slide',
        direction: 'vertical',
        simulateTouch: false,
        pagination: {
            el: '.homeslideshow-pag .slide-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.homeslideshow-nav .slide-button-next',
            prevEl: '.homeslideshow-nav .slide-button-prev',
        },
        autoplay: {
            delay: 6000,
            autoplayDisableOnInteraction: true
        },
    });
}

product_image_slider();
akd_image_slider();

$(document).ready(function() {
    akd_compare_slider();
   // product_image_slider();
   // akd_image_slider();
    project_image_slider();
    franchise_slider();
    home_project_slider();
    team_slider();
    home_reviews_slider();
    youtube_slider();
    factory_slider_1()
    factory_slider_2();
    documents_slider();
    proektirovki_slider();
    //Слайды в списке проектов
    $(".project-item").each(function(i) {
        var $project_id = $(this).data('project_id');
        project_list_slider($project_id);
    });

    $('.project-item .swiper-pagination-bullet, .project-images .swiper-pagination-bullet').mouseover(function () {
        $(this).trigger('click');
    }); 

    //Слайды в блоках проекта
    $(".gallery-type-container").each(function(i) {
        var $block_id = $(this).data('gallery');
        project_block_slider($block_id);
    });

    $('.home-screen-1 .form-group input').keyup(function () {
        gallery.autoplay.stop();
    });

    $('.home-screen-1 .form-group input').on('focus', function () {
        gallery.autoplay.stop();
    });
});