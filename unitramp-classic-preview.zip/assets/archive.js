
(() => {
  const contact = document.currentScript.dataset.contact;
  const buttons = [...document.querySelectorAll('.burger')];
  function showMenu(open) {
    buttons.forEach(button => {
      button.classList.toggle('burger-active', open);
      button.setAttribute('aria-expanded', String(open));
      const label = button.querySelector('.burger-text');
      if (label) label.textContent = open ? 'Закрыть меню' : 'Меню';
    });
    document.body.classList.toggle('modal-open', open);
    document.body.classList.toggle('modal-open2', open);
    document.querySelectorAll('.overlay, .mega-menu').forEach(el => el.classList.toggle('active', open));
  }
  buttons.forEach(button => button.addEventListener('click', () => showMenu(!button.classList.contains('burger-active'))));
  document.querySelectorAll('.overlay').forEach(el => el.addEventListener('click', () => showMenu(false)));
  document.addEventListener('keydown', event => { if (event.key === 'Escape') showMenu(false); });
  document.addEventListener('submit', event => event.preventDefault());
  document.addEventListener('click', event => {
    const button = event.target.closest('button.send, button[data-target="#callme-modal"], button[data-toggle="modal"]');
    if (button) { event.preventDefault(); window.location.assign(contact); }
  });
  if (typeof window.Swiper === 'function') {
    ['home_project_slider','home_reviews_slider','team_slider','youtube_slider','factory_slider_1','factory_slider_2',
     'documents_slider','proektirovki_slider','akd_image_slider','project_image_slider'].forEach(name => {
      if (typeof window[name] === 'function') window[name]();
    });
  }
})();
